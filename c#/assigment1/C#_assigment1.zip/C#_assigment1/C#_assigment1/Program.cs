﻿using System.Drawing;
using System.Runtime.InteropServices;

namespace C__assigment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1-
            #region ex1
            //int x = int.Parse(Console.ReadLine());
            //Console.WriteLine(x);
            #endregion

            //2-
            #region ex2
            //int x =5;
            //int y = x;

            //Console.WriteLine( x +" " + y);

            ///* x is = to y */

            //x = 10;

            //Console.WriteLine(x + " " + y);

            ///* now x is =10 and y =5*/
            #endregion

            //3-
            #region ex3
            //point p1;
            //point p2;
            //p1 = new point();
            //p2 = new point();

            //Console.WriteLine(p1.x);
            //Console.WriteLine(p2.x);
            //p1 = p2; ;
            
            //p1.x = 10;
            //Console.WriteLine(p1.x);
            //Console.WriteLine(p2.x);
            ///* now the refernce is same so it points to the same block in the memory and the values is the same*/





            #endregion
        }
    }
}
